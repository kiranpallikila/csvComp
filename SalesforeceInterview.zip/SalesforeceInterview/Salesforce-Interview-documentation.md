# Salesforce Interview Documentation

## 1. Troubleshooting Out of Memory Error.
## 2. API Documentation.


###  Troubleshooting Out of Memory Error.

Tools used: Anypoint Studio 7.8, Mule runtime 4.3, Maven 3.8, IBM Heap Analyzer.

### Problem creation and observations.

```sh
Ran Application with -Xmx150m and -Xms150m.
After running the application for 1 minute, it failed and throwed out of memory Error.
Collected heap dump "java_pid9372.hprof"
Using IBM Heap Analyzer inspected data.
Possible leak suspect of Customer object.
Producer creating 100k customer objects for every 1sec.
Consumer start consuming customer object after 5 sec with no delay.
By the time consumer start processing first Customer object, there are 4 customer objects waiting in queue which will create contention.
```

### Solution/Recommendation

```sh
Increase Producer frequency to 5 sec and have consumer frequency to 5 sec with 2 sec delay.
Increase heap Size.
Update GC policy +UseG1GC +UseStringDeduplication.
We can use persistent queue by writing to disk but it will be slower and consumes more resources.
Implement equals and hash code methods in Customer java class to eliminate duplicates.

```

### 2. API Documentation.
API transfers files from root configured folder to respective folders based on file format and sends email to requested parties.

### How to configure API
Install AnypointStudio and configure JAVA_HOME and MAVEN_HOME and Install Mule runtime 4.3.0.
#root file directory: C:\Tools\SalesforceInterview\files
#image directory : C:\Tools\SalesforceInterview\files\images
#textFiles directory : C:\Tools\SalesforceInterview\files\textFiles
#pdfFiles directory : C:\Tools\SalesforceInterview\files\pdfFiles
#Email configured in secure.properties
```sh  smtp.host=smtp.gmail.com
  smtp.port=465
  smtp.user= salesforcedemo
  smtp.userFrom = salesforcedemo
  smtp.password= xxxxxxxx
  http.port=8099
```
### How to Run
Using Postman or any Rest Code Client, No basic auth or Client id policies are enforced.
```sh
Request: GET http://127.0.0.1:8099/fileMove
```
Once  the request comes to API, HTTP listener process the request. and list all the files in the root directory. if files exists in that directory, we will get Array List consists all the files. Based on payload size, it routes to choice router where we check file format for the each file using For-each, and if there is a match for the specific format, those files transferred to corresponding folders. After successful file transfer, email notification will be triggered and sends email using Gmail smtp host.
```sh

if file foramt is .log, all the text files transferred to #textFiles directory
if file foramt is .PNG, all the images transferred to #textFiles directory
if file foramt is .log, all the pdf files it get transferred to #pdfFiles directory
```
### Testing
### Successful response.

```sh
http status code: 200 with below json response.
{
	resultInfo: resultCode: {
		tc: "1"
	},
	resultInfoDesc: "Files transferred and email notification sent.",
}
```
### Successful response, files dont exist in root folder.

```sh
http status code: 200
{
	resultInfo: resultCode: {
		tc: "2"
	},
	resultInfoDesc: "No files exist for transfer.",
}
```
### FILE:ACCESS_DENIED, FILE:CONNECTIVITY, FILE:FILE_ALREADY_EXISTS, FILE:ILLEGAL_PATH.

```sh
http status code: 200
{
	resultInfo: resultCode: {
		tc: "2"
	},
	resultInfoDesc: "No Files Moved",
}
```
### EMAIL:CONNECTIVITY, EMAIL:SEND

```sh
http status code: 200
{
	resultInfo: resultCode: {
		tc: "2"
	},
	resultInfoDesc: "Files Transfer done,Email notification failed",
}
```
### EMAIL:CONNECTIVITY, EMAIL:SEND

```sh
http status code: 200
{
	resultInfo: resultCode: {
		tc: "2"
	},
	resultInfoDesc: "Files Transfer done,Email notification failed",
}
```
