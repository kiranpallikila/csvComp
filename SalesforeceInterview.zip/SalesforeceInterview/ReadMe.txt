Included below documents.
Salesforce Interview Documentation.doc ( For detailed Information)
Salesforce-Interview-Presentation.ppt  ( Presentation for the interview)
Salesforce-Interview-documentation.md ( Open in ATOM browser and for the preview Ctrl+Shift+M)


Salesforce-demo.jar (Import .jar file into Studio)
troubleshooting-exercise.jar (Import .jar file into Studio)

OR

Saleforce-demo.zip  (Unzip to folder and Import as File System)
troubleshooting-exercise.zip (Unzip to folder and Import as File System)